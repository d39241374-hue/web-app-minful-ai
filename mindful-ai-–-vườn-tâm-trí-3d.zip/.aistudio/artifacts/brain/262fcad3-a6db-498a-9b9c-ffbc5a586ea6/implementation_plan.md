# Kế Hoạch Nâng Cấp Toàn Diện Mindful AI (Vườn Tâm Trí 3D & Học Tập Tập Trung)

Nâng cấp trang web **Mindful AI** từ một tệp HTML đơn lẻ lưu cục bộ thành một ứng dụng web full-stack hiện đại trên nền tảng **React + Express + Gemini AI + Firebase + Three.js**. Bản nâng cấp tích hợp trí tuệ nhân tạo thật cho Cố vấn tâm lý & Gia sư (Toán, Văn, Anh), nâng tầm đồ họa Vườn Cây Tri Thức & Thiên Long 3D, thiết kế lại giao diện kính mờ Aurora tinh gọn, đồng thời đồng bộ tài khoản và tiến độ học tập qua đám mây.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Xác nhận các lựa chọn đã thống nhất & bước cấp quyền khi triển khai:**
> - **Đã chốt từ bạn**: Tích hợp Gemini AI thật (Cố vấn & Gia sư Toán/Văn/Anh, Phân tích Sổ tay 7 mục + lộ trình CDS-HS, Tự động chia nhỏ mục tiêu thành nhiệm vụ học); Giao diện React kính mờ Aurora tinh gọn sang trọng; Nâng cấp đồ họa Vườn 3D & Thiên Long; Lưu trữ và đồng bộ qua Firebase.
> - **Cấp quyền Firebase khi thực thi**: Ngay sau khi bạn bấm duyệt kế hoạch, hệ thống sẽ mở hộp thoại xác nhận thiết lập Firebase (Google Sign-In & Firestore) để khởi tạo cơ sở dữ liệu đám mây thật cho ứng dụng.

- **Phương thức đăng nhập trên Firebase**: Mặc định sử dụng **Đăng nhập Google (Google Sign-In popup)** được cấp sẵn khi khởi tạo Firebase, kết hợp giữ lại **Chế độ Ban Giám Khảo (Judge Mode)** xem thử toàn bộ 10 cấp độ cây mà không ghi đè dữ liệu học sinh thật.
- **Lựa chọn mô hình Gemini AI**: Sử dụng **`gemini-4-hydrogen`** qua API server-side để phản hồi nhanh, hỗ trợ JSON có cấu trúc cho phân tích nhật ký & chia nhỏ bài tập mà hoạt động ổn định với khóa API tiêu chuẩn (không phát sinh bước yêu cầu khóa trả phí).

---

## 1. Overview & Core Concept

- **Mục tiêu sản phẩm**: Xây dựng không gian học tập tỉnh thức dành cho học sinh THPT (dự án KHKT THPT Hương Khê), giúp giảm **Bất hòa nhận thức số (CDS-HS)**, nâng cao thời lượng **Deep Work**, và nuôi dưỡng động lực học tập qua hệ sinh thái **Cây Tri Thức 3D & Thiên Long Ngân Hà**.
- **Đối tượng sử dụng**: Học sinh THPT tự học hằng ngày, bạn bè đồng hành học nhóm, giáo viên/nhà nghiên cứu xuất dữ liệu SPSS CSV, và Ban Giám Khảo trải nghiệm demo.
- **Giá trị cốt lõi mới**: Thay thế hoàn toàn bộ trả lời kịch bản tĩnh bằng **Gemini AI thật** trên máy chủ bảo mật, chuyển đổi dữ liệu từ `localStorage` đơn máy sang **Firestore thời gian thực** để kết bạn, thăm vườn 3D và tặng XP xuyên thiết bị.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Đăng nhập & Khởi tạo tỉnh thức**: Người dùng đăng nhập bằng tài khoản Google (hoặc vào nhanh Chế độ Ban Giám Khảo để trình diễn) $\rightarrow$ Nếu là học sinh mới, hoàn thành hồ sơ tên cây 3D, lớp/trường và bài kiểm tra đầu vào CDS-HS 2 bước $\rightarrow$ Gemini AI đề xuất lộ trình học tập đầu tiên.
2. **Vườn Tâm Trí 3D & Thanh điều khiển đáy thu gọn**: Màn hình chính dành toàn bộ không gian trung tâm cho khung cảnh 3D (Cây Tri Thức cấp 1–10 + Thiên Long + Đảo nổi + Tưới mưa), mọi nút chuyển cấp độ, góc nhìn và hiệu ứng nằm gọn trong một thanh kính mờ ở cạnh dưới có thể thu gọn (Zen Mode) để không che khuất cây và rồng.
3. **Phòng Deep Work & Âm thanh trị liệu**: Đồng hồ Aurora đa sắc kết hợp chọn mục tiêu bài học, chọn bạn đồng hành (+15% XP), bộ trộn sóng não Binaural (Alpha/Beta/Theta) + tiếng mưa Web Audio, nhịp thở 4-7-8, và chế độ Demo nhanh 10 giây cho BGK. Khi chuyển tab trình duyệt, hệ thống kích hoạt thông báo nhắc nhở & Màng lọc thức tỉnh Socratic.
4. **Nhiệm vụ học & Chia nhỏ mục tiêu bằng AI**: Học sinh nhập một mục tiêu lớn (ví dụ: *"Ôn thi giữa kỳ Hàm số bậc hai trong 3 ngày"*) $\rightarrow$ Gemini AI tự động phân tách thành 3–6 nhiệm vụ cụ thể theo môn học kèm ước lượng thời gian Deep Work và cho phép thêm hàng loạt chỉ với 1 lần nhấn.
5. **Sổ tay 7 mục & Phân tích nhận thức Gemini AI**: Sau khi điền 7 mục phản chiếu, Gemini AI đánh giá bẫy nhận thức (ảo giác "lướt 5 phút", né tránh bài khó, phân mảnh chú ý), đối chiếu điểm CDS-HS gần nhất và gợi ý hành động cụ thể cho ngày hôm sau. Giữ nguyên lớp lọc từ khóa khẩn cấp an toàn (tổng đài 111) ngay lập tức.
6. **Cố vấn Tâm lý & Gia sư 1-1 (Toán, Văn, Anh) + Diễn đàn trường**: Chat Tổng thời gian thực toàn trường qua Firestore và kênh Chat Riêng 1-1 với Cố vấn/Gia sư Gemini AI (nhớ ngữ cảnh hội thoại, gợi ý từng bước cho Toán, dàn ý cho Ngữ văn, giải nghĩa/sửa câu cho Tiếng Anh) cùng Chat riêng giữa bạn bè.
7. **Bạn bè, Nâng cấp Thiên Long & Nghiên cứu KHKT**: Kết bạn thật giữa các tài khoản Firebase, ghé thăm vườn 3D của bạn, tặng Điểm Mầm lấy XP duy trì chuỗi chung, nâng cấp 5 bậc Thiên Long Ngân Hà, xem Bảng xếp hạng trực tuyến, Biểu đồ CDS-HS & Deep Work 7 ngày, và xuất file CSV phục vụ SPSS.

### Visual Identity & Theme
- **Aesthetic Direction**: **Aurora Glassmorphic Editorial** — Kính mờ tinh gọn, thanh thoát và tập trung. Loại bỏ hoàn toàn cảm giác chật chội, loại bỏ các thẻ lồng thẻ (cards within cards), viền trái dày hay các viên thuốc (pill badges) bọc quanh dữ liệu tĩnh.
- **Color Palette & Dual-Theme (Light / Dark Mode)**:
  - *60% Nền chủ đạo*: Kem sương dịu mắt (`#F8FAF7`) ở chế độ Ngày và Xanh Rừng Đêm sâu (`#0B120E`) ở chế độ Đêm, kết hợp dải sáng Aurora nhẹ ở viền khung trang.
  - *30% Bề mặt cấu trúc*: Kính mờ tinh sạch với đường viền mảnh 1px (`border-black/8` sáng / `border-white/10` tối) và độ chênh lệch sắc độ có kiểm soát. Sử dụng `@custom-variant dark` chuẩn Tailwind v4 để đồng bộ 100% sáng/tối không lỗi tương phản.
  - *10% Điểm nhấn chức năng*: Xanh Rêu Tỉnh Thức (`#3F6212` / `#65A30D`) kết hợp dải chuyển sắc Aurora tại nút hành động chính, thanh tiến trình XP và vòng đồng hồ Deep Work.
- **Typography & Hierarchy**:
  - *Tiêu đề & Thương hiệu*: **`Plus Jakarta Sans`** (SemiBold/Bold, `text-wrap: balance`, không viết hoa toàn bộ gắt mắt).
  - *Nội dung đọc & Gợi ý AI*: **`DM Sans`** (15px–16px, giãn dòng 1.6 dễ đọc trên cả desktop và di động).
  - *Số liệu, Đồng hồ & Bảng SPSS*: **`JetBrains Mono`** kết hợp `tabular-nums` giúp đồng hồ đếm ngược và số liệu XP/CDS-HS thẳng hàng tuyệt đối, không giật khung.
- **Zero-Pill & Static Status Discipline**: Dữ liệu tĩnh như ngày tháng, lớp học, cấp cây, điểm số dùng văn bản sạch ngăn cách bằng dấu `·` thay vì nhồi nhét hàng loạt pill bo tròn. Không dùng các chấm tròn nhấp nháy (`animate-pulse`) trang trí trên tiêu đề hay điều hướng.

### 3D Graphics Upgrade (Three.js)
- **Kỹ thuật dựng hình & Vật liệu PBR chuẩn xác**:
  - Áp dụng **`RoomEnvironment` + `PMREMGenerator`** tạo bản đồ phản xạ môi trường studio không phụ thuộc file ngoài, giúp chất liệu Bạch Kim, Vàng Đồng (Cấp 10), pha lê Long Mạch (Cấp 8–9) và vảy Thiên Long có chiều sâu ánh kim thật.
  - Bổ sung bộ nhận diện **Software WebGL Guard (`isSoftwareGl`)**: tự động tối ưu pixel ratio, tắt shadow/post-processing nặng khi chạy trên GPU phần mềm nhưng giữ nguyên toàn bộ vật thể, ánh sáng và logic cảnh để trải nghiệm ổn định trên mọi máy học sinh.
  - Áp dụng **exponential damping (`THREE.MathUtils.damp`)** cho mọi chuyển động chuyển góc nhìn (Toán cảnh, Cận cảnh tán lá, Góc gốc) và ngắt ngay khi người dùng xoay tay (`OrbitControls 'start'`).
  - Bảo đảm vòng đời WebGL ổn định trong React bằng container `useRef` độc lập (không gắn `backdrop-filter` đè lên canvas WebGL để tránh nghẽn GPU), dọn dẹp triệt để `geometry`/`material`/`texture`/`renderer` khi chuyển tab, và cấp sẵn sự kiện `webglcontextlost`.
  - Bổ sung **bộ điều chỉnh thời tiết & ánh sáng động**: Tưới mưa dưỡng chất 3D, đom đóm ban đêm, cánh hoa anh đào cấp 7, và mây/hào quang cấp 8–10.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Kiến trúc Full-Stack React + Express thay cho Single HTML**
  - *Lựa chọn*: Tách ứng dụng thành giao diện React (TypeScript + Tailwind v4 + Motion) và máy chủ Express (`/api/*`) phục vụ cả API Gemini lẫn bundle Vite.
  - *Lý do*: Bảo vệ khóa `GEMINI_API_KEY` tuyệt đối ở phía server, cho phép chia module sạch sẽ (Vườn 3D, Deep Work, AI Coach, Firebase Sync, Nghiên cứu KHKT) và dễ bảo trì lâu dài.
  - *Phương án khác đã cân nhắc*: Giữ nguyên 1 tệp HTML thuần — bị loại vì không thể gọi Gemini API an toàn và khó nâng cấp giao diện mượt mà.

- **Decision 2: Gemini AI qua `gemini-4-hydrogen` với Structured JSON & Streaming/Chat**
  - *Lựa chọn*: Dùng mô hình `gemini-4-hydrogen` cho 3 tác vụ chính: (1) Chat Cố vấn Tâm lý & Gia sư 3 môn Toán–Văn–Anh; (2) Phân tích Sổ tay 7 mục + điểm CDS-HS thành JSON có cấu trúc (`cognitiveTrap`, `empathyNote`, `studyPlan`); (3) Chia nhỏ mục tiêu học tập thành JSON danh sách nhiệm vụ kèm môn học & thời lượng gợi ý.
  - *Lý do*: Phản hồi nhanh, chi phí thấp, hỗ trợ `ThinkingLevel` linh hoạt và `responseSchema` chính xác mà không yêu cầu người dùng phải cấu hình billing key trả phí.

- **Decision 3: Lưu trữ Firebase (Google Auth + Firestore) kèm chế độ Ban Giám Khảo**
  - *Lựa chọn*: Toàn bộ hồ sơ cây 3D, điểm XP, Điểm Mầm, nhật ký, nhiệm vụ, CDS-HS, bạn bè, quà tặng và Chat Tổng được đồng bộ trực tiếp trên Firestore với các bộ quy tắc bảo mật chặt chẽ (Eight Pillars). Giữ lại nút "Chế độ Ban Giám Khảo" hoạt động tách biệt trên state xem thử (read-only/sandbox) với đầy đủ 10 cấp độ cây để trình diễn nhanh khi chấm thi.
  - *Lý do*: Đáp ứng đúng yêu cầu kết bạn thật, thăm vườn 3D của bạn bè từ máy khác, và bảo toàn dữ liệu khi đổi thiết bị.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        REACT CLIENT (Vite + Tailwind v4)                   │
│                                                                            │
│  ┌──────────────────┐   ┌───────────────────────────────────────────────┐  │
│  │ Collapsible Rail │   │               Active Workspace                │  │
│  │  & Mobile Dock   │──▶│  • 3D Mind Garden (Three.js Ref + Bottom Dock)│  │
│  └──────────────────┘   │  • Deep Work Clock, Binaural Audio & 4-7-8     │  │
│                         │  • Tasks (+ AI Goal Splitter) & Plant Quests  │  │
│  ┌──────────────────┐   │  • CDS-HS Assessment + 7-Item Journal (AI)    │  │
│  │ Auth & Theme Ctx │   │  • AI Tutor/Counselor & School Forum Chat     │  │
│  │ (Light / Dark)   │   │  • Friends, Dragon Upgrades & KHKT SPSS Lab   │  │
│  └────────┬─────────┘   └───────────────┬───────────────┬───────────────┘  │
└───────────┼─────────────────────────────┼───────────────┼──────────────────┘
            │ Firebase SDK                │ REST / JSON   │ Web Audio / Vis API
            ▼                             ▼               ▼
┌───────────────────────────┐   ┌──────────────────┐   ┌─────────────────────┐
│   FIREBASE CLOUD SERVICES │   │  EXPRESS SERVER  │   │  BROWSER NATIVE API │
│  • Google Authentication  │   │  /api/ai/chat    │   │  • Binaural + Rain  │
│  • Firestore Collections: │   │  /api/ai/journal │   │  • Page Visibility  │
│    users, publicGardens,  │   │  /api/ai/tasks   │   │  • Notifications    │
│    tasks, journals,       │   └────────┬─────────┘   └─────────────────────┘
│    cdsRecords, friends,   │            │ @google/genai
│    forumMessages, chats   │            ▼
└───────────────────────────┘   ┌──────────────────┐
                                │    GEMINI API    │
                                │ gemini-4-hydrogen│
                                └──────────────────┘
```

### Data Model & State (Firestore Schema & Security Strategy)
- **Tách dữ liệu công khai & riêng tư (PII Isolation)**:
  - Hồ sơ cá nhân chứa email, mật khẩu/cài đặt riêng tư và tiến độ nhạy cảm nằm ở nhánh riêng của chủ sở hữu (`users/{uid}`).
  - Hồ sơ vườn công khai phục vụ Bảng xếp hạng, Kết bạn và Thăm vườn 3D (`publicGardens/{uid}`) chỉ chứa tên hiển thị, lớp, trường, tên cây, cấp độ cây (1–10), XP, chuỗi ngày, và cấp nâng cấp Thiên Long — không chứa email hay nội dung nhật ký tâm lý.
- **Các phân nhánh dữ liệu của học sinh**:
  - `tasks`: Nhiệm vụ học tập (tiêu đề, môn học, trạng thái hoàn thành, thời lượng ước tính, nguồn tạo thủ công/AI).
  - `journals`: Sổ tay 7 mục kèm kết quả phân tích bẫy nhận thức & lời khuyên do Gemini trả về.
  - `cdsRecords`: Lịch sử đánh giá thang đo CDS-HS 10 câu (1.0–5.0) theo ngày để vẽ biểu đồ tiến bộ.
  - `gardenLogs` & `friendRequests` / `friends`: Lời mời kết bạn, chuỗi chăm cây chung (`sharedStreaks`) và lịch sử bạn bè ghé thăm tặng XP.
  - `forumMessages` & `privateChats`: Tin nhắn Chat Tổng toàn trường và kênh trò chuyện 1-1.
- **Bảo mật Firestore Rules**: Mọi thao tác đọc/ghi bắt buộc xác thực `request.auth != null`, xác minh `email_verified`, kiểm tra kích thước chuỗi (`.size()`), chặn trường ẩn (strict `hasOnly`), chỉ chủ sở hữu mới được đọc/sửa nhật ký tâm lý và điểm CDS-HS cá nhân, và tách riêng hành động tặng Điểm Mầm/XP từ bạn bè qua trường cho phép cụ thể.

### Interactive Component & State Mapping
- **3D Mind Garden Stage**: Quản lý qua `useRef` mount container và imperative controller (chuyển cấp 1–10, zoom, preset góc nhìn `overview` / `canopy` / `reset`, bật mưa 3D, đồng bộ ánh sáng ngày/đêm, hiệu ứng pháo hoa nâng cấp). Mọi nút điều khiển gom về thanh dock đáy thu gọn.
- **Deep Work & Tab Focus Guard**: Bộ đếm dựa trên `endTimestamp` thực tế (không trôi giờ khi chuyển tab), lắng nghe `visibilitychange` để ghi nhận thời gian rời tab, gửi Notification trình duyệt (khi đã cấp quyền) và bật modal Màng lọc thức tỉnh Socratic có cộng XP khi quay lại bài học.
- **AI Endpoints trên `server.ts`**:
  - `POST /api/ai/counselor`: Nhận lịch sử hội thoại, môn học/chủ đề (Tâm lý, Toán, Ngữ văn, Tiếng Anh) và tóm tắt trạng thái học tập ẩn danh (cấp cây, điểm CDS-HS) để trả lời thân thiện, sư phạm, có nhắc rõ giới hạn không thay thế chuyên gia y tế.
  - `POST /api/ai/analyze-journal`: Nhận nội dung 7 mục sổ tay + điểm CDS-HS, dùng `responseSchema` trả về JSON gồm `cognitiveTrap` (tên bẫy nhận thức), `insight` (phản hồi Socratic), và `nextStep` (gợi ý hành động cho phiên Deep Work tiếp theo).
  - `POST /api/ai/breakdown-goal`: Nhận mục tiêu học tập bằng ngôn ngữ tự nhiên, trả về JSON mảng 3–6 nhiệm vụ gồm `text`, `category` (`Toán Học` | `Văn Học` | `Khoa Học` | `Ngoại Ngữ`), và `estimatedMins` để học sinh thêm ngay vào danh sách nhiệm vụ.
  - Xử lý lỗi API chuẩn xác: Trả về mã HTTP và thông điệp rõ ràng nếu thiếu key hoặc quá tải, hiển thị thông báo lỗi thân thiện trên UI (không giả lập câu trả lời giả).
